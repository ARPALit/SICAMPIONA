﻿using SICampionaAPI.Features.Campionamenti;
using System.Globalization;

namespace SICampionaAPI.Data
{
    public partial class CampionamentoDB
    {
        public static explicit operator Campionamento(CampionamentoDB campionamentoDB)
        {
            var campionamento = new Campionamento
            {
                IdCampionamento = (int)campionamentoDB.ID_CAMPIONAMENTO,
                Ente = new Ente()
                {
                    Codice = campionamentoDB.ENTE_CODICE,
                    Denominazione = campionamentoDB.ENTE_DENOMINAZIONE
                },
                Matrice = new Matrice()
                {
                    Codice = campionamentoDB.MATRICE_CODICE,
                    Denominazione = campionamentoDB.MATRICE_DENOMINAZIONE
                },
                Argomento = new Argomento()
                {
                    Codice = campionamentoDB.ARGOMENTO_CODICE,
                    Denominazione = campionamentoDB.ARGOMENTO_DENOMINAZIONE
                },
                Cliente = new Cliente()
                {
                    Codice = campionamentoDB.CLIENTE_CODICE,
                    Denominazione = campionamentoDB.CLIENTE_DENOMINAZIONE,
                    CodiceFiscale = campionamentoDB.CLIENTE_CODICE_FISCALE,
                    PartitaIVA = campionamentoDB.CLIENTE_PARTITA_IVA
                },
                DescrizioneAttivita = campionamentoDB.DESCRIZIONE_ATTIVITA,
                DataOraCreazioneCampionamento = campionamentoDB.DATA_ORA_CREAZIONE,
                CodiceFiscaleOperatoreCreazioneCampionamento = campionamentoDB.CF_OPERATORE_CREAZIONE,
                DataPrelievo = DateOnly.FromDateTime(campionamentoDB.DATA_PRELIEVO),
                OraPrelievo = !string.IsNullOrEmpty(campionamentoDB.ORA_PRELIEVO) ? TimeOnly.ParseExact(campionamentoDB.ORA_PRELIEVO, "HH:mm", CultureInfo.InvariantCulture) : null,
                DataOraChiusuraCampionamento = campionamentoDB.DATA_ORA_CHIUSURA,
                UltimoAggiornamento = new UltimoAggiornamento()
                {
                    DataOra = campionamentoDB.ULTIMO_AGG_DATA_ORA,
                    Operatore = new Operatore()
                    {
                        Codice = campionamentoDB.ULTIMO_AGG_OPER_CODICE,
                        Cognome = campionamentoDB.ULTIMO_AGG_OPER_COGNOME,
                        Nome = campionamentoDB.ULTIMO_AGG_OPER_NOME,
                        CodiceFiscale = campionamentoDB.ULTIMO_AGG_OPER_CF
                    },
                },
                SiglaVerbale = campionamentoDB.SIGLA_VERBALE,
                NumeroCampione = campionamentoDB.NUMERO_CAMPIONE,
                Eliminato = campionamentoDB.ELIMINATO,
                FileVerbale = campionamentoDB.FILE_VERBALE,
                FileRapportoDiProva = campionamentoDB.FILE_RAPPORTO_DI_PROVA,
                StatoCampione = campionamentoDB.STATO_CAMPIONE,
                CartellaFile = $"{campionamentoDB.ID_CAMPIONAMENTO}_{campionamentoDB.SUFFISSO_CARTELLA}",
                CodiceSedeAccettazione = campionamentoDB.CODICE_SEDE_ACCETTAZIONE,
                DataAperturaCampione = campionamentoDB.DATA_APERTURA_CAMPIONE.HasValue ? DateOnly.FromDateTime(campionamentoDB.DATA_APERTURA_CAMPIONE.Value) : null,
                OraAperturaCampione = !string.IsNullOrEmpty(campionamentoDB.ORA_APERTURA_CAMPIONE) ? TimeOnly.ParseExact(campionamentoDB.ORA_APERTURA_CAMPIONE, "HH:mm", CultureInfo.InvariantCulture) : null,
                EmailInvioVerbale = campionamentoDB.EMAIL_INVIO_VERBALE,
                PECInvioVerbale = campionamentoDB.PEC_INVIO_VERBALE,
                CampionamentoCollegato = campionamentoDB.CAMPIONAMENTO_COLLEGATO,
                TipoCampionamento = campionamentoDB.TIPO_CAMPIONAMENTO,
                FileVerbaleFirmato = campionamentoDB.FILE_VERBALE_FIRMATO,
                CampioneBianco = campionamentoDB.CAMPIONE_BIANCO,
                TemperaturaAccettazione = campionamentoDB.TEMPERATURA_ACCETTAZIONE,
                LuogoAperturaCampione = campionamentoDB.LUOGO_APERTURA_CAMPIONE,
                Note = campionamentoDB.NOTE
            };

            if (campionamentoDB.PUNTO_ARPAL_CODICE != null)
            {
                campionamento.PuntoDiPrelievoARPAL = new PuntoDiPrelievo()
                {
                    Codice = campionamentoDB.PUNTO_ARPAL_CODICE,
                    Denominazione = campionamentoDB.PUNTO_ARPAL_DENOMINAZIONE,
                    Indirizzo = campionamentoDB.PUNTO_ARPAL_INDIRIZZO,
                    Comune = new Comune()
                    {
                        CodiceIstat = campionamentoDB.PUNTO_ARPAL_COMUNE_CODICE,
                        Denominazione = campionamentoDB.PUNTO_ARPAL_COMUNE_DENOMINAZ
                    }
                };
                if (campionamentoDB.PUNTO_ARPAL_LATITUDINE != null || campionamentoDB.PUNTO_ARPAL_LONGITUDINE != null)
                {
                    campionamento.PuntoDiPrelievoARPAL.Coordinate = new Coordinate()
                    {
                        Latitudine = campionamentoDB.PUNTO_ARPAL_LATITUDINE,
                        Longitudine = campionamentoDB.PUNTO_ARPAL_LONGITUDINE
                    };
                }
            }

            if (campionamentoDB.PUNTO_OPER_CODICE != null)
            {
                campionamento.PuntoDiPrelievoInseritoDaOperatore = new PuntoDiPrelievo()
                {
                    Codice = campionamentoDB.PUNTO_OPER_CODICE,
                    Denominazione = campionamentoDB.PUNTO_OPER_DENOMINAZ,
                    Indirizzo = campionamentoDB.PUNTO_OPER_INDIRIZZO,
                    Comune = new Comune()
                    {
                        CodiceIstat = campionamentoDB.PUNTO_OPER_COMUNE_CODICE,
                        Denominazione = campionamentoDB.PUNTO_OPER_COMUNE_DENOMINAZ
                    }
                };
                if (campionamentoDB.PUNTO_OPER_LATITUDINE != null || campionamentoDB.PUNTO_OPER_LONGITUDINE != null)
                {
                    campionamento.PuntoDiPrelievoInseritoDaOperatore.Coordinate = new Coordinate()
                    {
                        Latitudine = campionamentoDB.PUNTO_OPER_LATITUDINE,
                        Longitudine = campionamentoDB.PUNTO_OPER_LONGITUDINE
                    };
                }
            }

            campionamento.Prelevatori = [];
            foreach (var prelevatore in campionamentoDB.PRELEVATORI)
            {
                campionamento.Prelevatori.Add(new Features.Campionamenti.Prelevatore()
                {
                    Codice = prelevatore.CODICE,
                    Cognome = prelevatore.COGNOME,
                    Nome = prelevatore.NOME
                });

            }

            campionamento.PrelevatoriSelezionabili = [];
            foreach (var prelevatore in campionamentoDB.PRELEVATORI_SELEZIONABILI)
            {
                campionamento.PrelevatoriSelezionabili.Add(new Features.Campionamenti.Prelevatore()
                {
                    Codice = prelevatore.CODICE,
                    Cognome = prelevatore.COGNOME,
                    Nome = prelevatore.NOME
                });

            }

            campionamento.MisureInLoco = [];
            foreach (var misuraInLoco in campionamentoDB.MISURE_IN_LOCO)
            {
                campionamento.MisureInLoco.Add(new Features.Campionamenti.MisuraInLoco()
                {
                    Codice = misuraInLoco.CODICE,
                    Descrizione = misuraInLoco.DESCRIZIONE,
                    CodiceMetodo = misuraInLoco.METODO_CODICE,
                    DescrizioneMetodo = misuraInLoco.METODO_DESCRIZIONE,
                    UnitaMisura = misuraInLoco.UNITA_MISURA,
                    Valore = misuraInLoco.VALORE
                });
            }

            campionamento.Analiti = [];
            foreach (var analita in campionamentoDB.ANALITI)
            {
                var contenitori = new List<Features.Campionamenti.Contenitore>();
                foreach (var contenitore in analita.CONTENITORI)
                {
                    contenitori.Add(new Features.Campionamenti.Contenitore()
                    {
                        Tipo = contenitore.TIPO,
                        Quantita = (int)contenitore.QUANTITA
                    });
                }
                campionamento.Analiti.Add(new Features.Campionamenti.Analita()
                {
                    Codice = analita.CODICE,
                    Descrizione = analita.DESCRIZIONE,
                    CodiceMetodo = analita.METODO_CODICE,
                    DescrizioneMetodo = analita.METODO_DESCRIZIONE,
                    CodicePacchetto = analita.PACCHETTO_CODICE,
                    DescrizionePacchetto = analita.PACCHETTO_DESCRIZIONE,
                    ValoreLimite = analita.VALORE_LIMITE,
                    UnitaMisura = analita.UNITA_MISURA,
                    RimossoDaOperatore = analita.RIMOSSO_DA_OPER.HasValue && analita.RIMOSSO_DA_OPER.Value,
                    AggiuntoDaOperatore = analita.AGGIUNTO_DA_OPER.HasValue && analita.AGGIUNTO_DA_OPER.Value,
                    Contenitori = contenitori,
                    Ordinamento = (int)analita.ORDINAMENTO
                });
            }

            if (campionamentoDB.NOTA_ACCETTAZIONE != null)
            {
                campionamento.NotaAccettazione = new NotaAccettazione()
                {
                    Testo = campionamentoDB.NOTA_ACCETTAZIONE,
                    UltimoAggiornamento = new UltimoAggiornamento()
                    {
                        DataOra = campionamentoDB.NOTA_ACCETTAZIONE_DATA_ORA.Value,
                        Operatore = new Operatore()
                        {
                            Codice = campionamentoDB.NOTA_ACCETTAZIONE_OPER_CODICE,
                            Cognome = campionamentoDB.NOTA_ACCETTAZIONE_OPER_COGNOME,
                            Nome = campionamentoDB.NOTA_ACCETTAZIONE_OPER_NOME
                        }
                    }
                };
            }

            // PDF verbale e rapporto di prova non sono valorizzati
            // perché salvati su file e aggiunti al compionamento come
            // stringhe base64 solo nelle API che espongono i campionamenti
            // a sistemi esterni

            return campionamento;
        }
    }
}
